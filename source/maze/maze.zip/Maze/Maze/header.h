/* Author:          Chris Brough
 * File Name:       header.h
 * Date:            9/13/10
 *
 * Description:     This program is used to load a maze from a file
 *                  created by '1''s and '0''s, which will be used
 *                  to move a character in one direction (right) around
 *                  the maze to find an exit. If no exit is available
 *                  then the character will continue moving right until
 *                  all open spaces in the map have been reached.
 *
 * Note:            Map files should be of type .txt,and use characters:
 *                  '1' for a wall and '0' for a open space. If
 *                  spaces (i.e. ' ') are used in the file, then they
 *                  will be skipped. Files should be located in the
 *                  same directory as the source files or user input
 *                  requires the entire path to the file.
 *                      ex.
 *                          C:\Users\User_Name\Documents\file.txt
 *******************************************************************/

#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include <string>
#include <time.h>       // For time() to seed srand()
#include <fstream>      // Used for file I/O
#include <windows.h>    // Used for system("cls")
using namespace std;

const int NUM_ROWS = 12;        // Number of rows in the Maze array
const int NUM_COLUMNS = 12;     // Number of columns in the Maze array.
const int NUM_CHAR = 512;       // Number of characters in file name.

struct Maze
{
    char tile;          // Holds one value of the maze map ('1' = wall
                        //      '0' = open space)
    bool freeTile;      // Holds boolean value to determine if the
                        //      space is open or not.
    Maze()
    {
        tile = '1';     // Initializes each tile to 1 (i.e. a wall)
    };
};

struct Settings
{
    char fileName[NUM_CHAR];    // Holds the file name inputted by the user.
    float time;                 // Holds the time value inputted by the user.
    int count;                  // Holds the number of empty spaces in a
                                //      maze map.
    Settings()
    {
    time = 1000;        // Time initialized to one second.
    count = 0;          // Count of free spaces initialized to 0.
    };
};

/* Pre:             None
 * Post:            User is asked to decide wether or not to exit.
 *                  Then the function returns the the users decision
 *                  back to the call.
 * Purpose:         The function is used to allow the user to exit
 *                  or continue using the program at a given point.
 *******************************************************************/
string exit();

/* Pre:             Must have declared: a 12 x 12 array of type Maze
 *                  and a variable of type Settings. The Settings
 *                  variable must be initialized using the
 *                  userSettings function. The Settings variable
 *                  must be passed in by reference. A file
 *                  containing a string of 144 characters: 1 for a
 *                  wall, and '0' for a open space (spaces may be
 *                  to seperate each character) are needed to
 *                  initialize the array.
 * Post:            The 12 x 12 array of type Maze will be
 *                  filled with values from a file, unless the file
 *                  name is invalid or a character within the file
 *                  is invalid. The function will return a boolean
 *                  value, which tells the caller wether the
 *                  values in the file were stored succesfully into
 *                  the array.
 * Purpose:         The function is used to store values from a
 *                  file into an a 12 x 12 array. The values stored
 *                  in the array are used to create the maze map.
 *******************************************************************/
bool load(Maze mazeMap[NUM_ROWS][NUM_COLUMNS], Settings* presets);

/* Pre:             Must have declared: a 12 x 12 array of type Maze
 *                  and a variable of type Settings. The Maze array
 *                  must be initialized with values using the load
 *                  function, and the Settings variable must be
 *                  initialized using the userSettings function.
 * Post:            Finds the position of the player as it moves
 *                  through the maze (following right - hand rule).
 *                  When the position of the player changes a call
 *                  to the print function is made. If there is an
 *                  exit in the maze, the player will find it and
 *                  stop. If there isn't an exit then the player
 *                  will make it's way to every open space in the
 *                  maze.
 * Purpose:         The function is used to find the next valid
 *                  position of the player using the right - hand
 *                  rule.
 *******************************************************************/
void move(Maze mazeMap[NUM_ROWS][NUM_COLUMNS], Settings presets);

/* Pre:             Must have declared: a 12 x 12 array of type Maze,
 *                  which must be initialized with values using the
 *                  load function.
 * Post:            The current values held in the Maze array are
 *                  displayed to the screen.
 * Purpose:         The function is used to print the maze.
 *******************************************************************/
void print(Maze mazeMap[NUM_ROWS][NUM_COLUMNS]);

/* Pre:             None
 * Post:            Asks user for file name, and time in between
 *                  moves. Those values will be stored inside of the
 *                  settings structure and then returned to the
 *                  caller.
 * Purpose:         The function is used to obtain values needed
 *                  for the load and move functions.
 *******************************************************************/
Settings userSettings();

#endif HEADER_H
