/* Author:          Chris Brough
 * File Name:       main.cpp
 * Due Date:        9/13/10
 *
 * Description:     This program is used to load a maze from a file
 *                  created by '1''s and '0''s, which will be used
 *                  to move a character in one direction (right) around
 *                  the maze to find an exit. If no exit is available
 *                  then the character will continue moving right until
 *                  all open spaces in the map have been reached.
 *
 * Note:            Map files should be of type .txt,and use characters:
 *                  '1' for a wall and '0' for a open space. If
 *                  spaces (i.e. ' ') are used in the file, then they
 *                  will be skipped. Files should be located in the
 *                  same directory as the source files or user input
 *                  requires the entire path to the file.
 *                      ex.
 *                          C:\Users\User_Name\Documents\file.txt
 *******************************************************************/

#include "header.h"

int main()
{
    Maze mazeMap[NUM_ROWS][NUM_COLUMNS];    // Declares array of type
                                            //      Maze.
    Settings userSet;                       // Declares variable of
                                            //      type settings.

    bool loadFile = true;                   // Declares variable of
                                            //      type bool, to
                                            //      determine if file
                                            //      loaded succesfully.
    string exitProgram = "N";               // Declares variable of
                                            //      type string, to
                                            //      determine if
                                            //      user want to exit.

    do                                      // Used to repeat the
                                            //      following instuctions
                                            //      until the user wants
                                            //      to exit.
    {
        userSet = userSettings();           // Sets values inputed by
                                            //      to Settings struct.
        loadFile = load(mazeMap, & userSet);// Stores values from file
                                            //      into Maze array,
                                            //      and receives bool
                                            //      value to determine
                                            //      wether file loaded
                                            //      succesfully.
        if(loadFile)
        {
            move(mazeMap, userSet);         // If file loaded succesfully
                                            //      move function is used
                                            //      to move the "player"
                                            //      around the maze using
                                            //      using the right hand
                                            //      rule.
        };
        exitProgram = exit();               // Determines wether user
                                            //      wants to exit.

    // Uses value returned by exit to continue or exit program.
    } while (exitProgram == "n" || exitProgram == "N");
    return 0;
}
