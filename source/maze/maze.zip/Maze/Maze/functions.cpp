/* Author:          Chris Brough
 * File Name:       functions.cpp
 * Date:            9/13/10
 *
 * Description:     This program is used to load a maze from a file
 *                  created by '1''s and '0''s, which will be used
 *                  to move a character in one direction (right) around
 *                  the maze to find an exit. If no exit is available
 *                  then the character will continue moving right until
 *                  all open spaces in the map have been reached.
 *
 * Note:            Map files should be of type .txt,and use characters:
 *                  '1' for a wall and '0' for a open space. If
 *                  spaces (i.e. ' ') are used in the file, then they
 *                  will be skipped. Files should be located in the
 *                  same directory as the source files or user input
 *                  requires the entire path to the file.
 *                      ex.
 *                          C:\Users\User_Name\Documents\file.txt
 *******************************************************************/

#include "header.h"

string exit()
{
    string exit;    // Declares string variable, which will be used
                    //      to determine wether to exit the program.
    do
    {
    cout << "Would you like to exit Y = Yes and N = No: ";
    cin >> exit;
    cin.ignore(1024,'\n');
    } while (exit != "Y" && exit != "y" && exit != "N" && exit != "n");
    //cin.ignore(1024,'\n');
    return exit;
}

bool load(Maze mazeMap[NUM_ROWS][NUM_COLUMNS], Settings* presets)
{
    ifstream inFile;    // Creates ifstream variable for input

    char ch = ' ';      // Used to hold characters from file

    // Opens file (defined by fileName in the Settings variable
    //      presets).
    inFile.open(presets->fileName, ios::in);

    // If input file is invalid function will return false to
    //      caller.
    if (!inFile)
    {
        cout << '"' << presets->fileName << '"'
             << " could not be opended. " << endl;
        cout << endl;
        return false;
    }

    // Loops through rows and columns of Maze array and stores
    //      an individual character in each element.
    // If tile is a free space then a boolean value of true
    //      will be stored in the current elements freeTile
    //      variable, otherwise a value of false will be
    //      stored.
    for (int i = 0; i < 12; i++)
    {
        for (int k = 0; k < 12; k++)
        {
            inFile.get(ch);
            switch (ch)
            {
                case '1':
                    mazeMap[i][k].tile = '1';
                    mazeMap[i][k].freeTile = false;
                    break;
                case '0':
                    mazeMap[i][k].tile = ' ';
                    mazeMap[i][k].freeTile = true;
                    presets->count++;
                    break;
                case ' ':
                    k--;
                    break;
                default:
                    // If an invalid character is found, then
                    //      the function will return false.
                    cout << '"' << ch << '"'
                         << " is an invalid character." << endl;
                    return false;
            }
        }
    }
    inFile.close(); // Close file
    return true;    // Returns true once the values in the file
                    //      have succesfully been stored in the
                    //      Maze array.
}

void move(Maze mazeMap[NUM_ROWS][NUM_COLUMNS], Settings presets)
{
    int right = 1,              // Holds current right position
        i, k,                   // Holds values for subscripts of Maze array
        iStart, kStart,         // Holds starting values for subcripts of Maze
                                //      array.
        max = 11, min = 0,      // Holds max and min values possible for
                                //      subscripts in Maze array.
        count = 0;              // Holds the current count of empty spaces
                                //      replaced by a '.'

    bool printCheck = true;     // Holds a bool value to determine wether
                                //      print function should be called.

    srand((unsigned)time(NULL));// Seeds srand() with time()

    do                          // Randomizes the starting location.
    {
        iStart = (rand() % (max - min + 1) + min); // Random number between min & max
        kStart = (rand() % (max - min + 1) + min); // Random number between min & max
        i = iStart;
        k = kStart;
    } while(mazeMap[iStart][kStart].freeTile == false ||
        iStart == 0 || iStart == 11 || kStart == 0 || kStart == 11);

    mazeMap[iStart][kStart].tile = '@'; // Changes starting position's value to '@'
    print(mazeMap);

    // Determines where the next move should be, and acts accordingly.
    while (presets.count != (count + 1) && i != 0 && i != 11 && k != 0 && k != 11)
    {
        Sleep(static_cast<int>(presets.time*1000)); // Used to pause in between each
                                                    //      move.

        // Checks wether the player can be moved right:
        //      If it can the current and next position will change to '.' and '@',
        //          respectively; print check will change to true; and the right
        //          position will be redetermined based on the current position.
        //          Note: If the space at which the player is to move to hasn't
        //                  been reached previously, then count will increase by
        //                  one.
        //      If it can't the right value will be redetermined in order to
        //          find an open space, and print check will change to false.
        switch (right)
        {
            case 1:
            {
                if (mazeMap[i][k-1].tile == ' ' || mazeMap[i][k-1].tile == '.')
                {
                    if (mazeMap[i][k-1].tile == ' ')
                    {
                        count++;
                    }
                    mazeMap[i][k].tile = '.';
                    k -= 1;
                    mazeMap[i][k].tile = '@';
                    right = 2;
                    printCheck = true;
                }
                else
                {
                    right = 4;
                    printCheck = false;
                }
                break;
            }
            case 2:
            {
                if (mazeMap[i-1][k].tile == ' ' || mazeMap[i-1][k].tile == '.')
                {
                    if (mazeMap[i-1][k].tile == ' ')
                    {
                        count++;
                    }
                    mazeMap[i][k].tile = '.';
                    i -= 1;
                    mazeMap[i][k].tile = '@';
                    right = 3;
                    printCheck = true;
                }
                else
                {
                    right = 1;
                    printCheck = false;
                }
                break;
            }
            case 3:
            {
                if (mazeMap[i][k+1].tile == ' ' || mazeMap[i][k+1].tile == '.')
                {
                    if (mazeMap[i][k+1].tile == ' ')
                    {
                        count++;
                    }
                    mazeMap[i][k].tile = '.';
                    k += 1;
                    mazeMap[i][k].tile = '@';
                    right = 4;
                    printCheck = true;
                }
                else
                {
                    right = 2;
                    printCheck = false;
                }
                break;
            }
            case 4:
            {
                if (mazeMap[i+1][k].tile == ' ' || mazeMap[i+1][k].tile == '.')
                {
                    if (mazeMap[i+1][k].tile == ' ')
                    {
                        count++;
                    }
                    mazeMap[i][k].tile = '.';
                    i += 1;
                    mazeMap[i][k].tile = '@';
                    right = 1;
                    printCheck = true;
                }
                else
                {
                    right = 3;
                    printCheck = false;
                }
                break;
            }
        }
        if (printCheck)
        {
            system("cls");  // Clears screen
            print(mazeMap); // Prints maze
        }
    }
}

void print(Maze mazeMap[NUM_ROWS][NUM_COLUMNS])
{
    // Loops through both the rows and columns of the Maze array
    //      in order to print each value.
    for (int i = 0; i < 12; i++)
    {
        for (int k = 0; k < 12; k++)
        {
            cout << " " << mazeMap[i][k].tile << " ";
        }
        cout << endl;
        cout << endl;
    }
}

Settings userSettings()
{
    Settings userDefined;   // Declares variable of type Settings
                            //      time and count variables are
                            //      initialized immediatley by
                            //      constructor.

    // User input to get file name and time interval in between moves.
    cout << "Please input file name including .txt "
         << "(e.g. exit.txt, noexit.txt): ";
    cin >> userDefined.fileName;
    cin.ignore(1024,'\n');
    do
    {
    cout << "Please input the time interval between moves "
         << "in seconds greater than 0: ";
    cin >> userDefined.time;
    } while (userDefined.time <= 0); // Used to verify time > 0
    cin.ignore();
    return userDefined;     // Returns Settings variable back to caller.
}
