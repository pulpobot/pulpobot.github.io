/* Author:          Chris Brough
 * Date:            4/4/11
 * Description:     Data for min-max tree.
 *******************************************************************/

#ifndef DATA_H
#define DATA_H

const int _PLAYER = 0;
const int _COMPUTER = 1;

const int INFINITY = 1000000;

const int COL = 3;
const int ROW = 3;

struct Data
{
    int s_min;
    int s_max;
    int s_map[ROW][COL];

    Data()
    {
        int i, k;

        s_max = -INFINITY;
        s_min = INFINITY;

        for (i = 0; i < ROW; i++)
        {
            for (k = 0; k < COL; k++)
            {
                s_map[k][i] = -1;
            }
        }
    }
};

#endif
