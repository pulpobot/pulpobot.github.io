/* Author:          Chris Brough
 * Date:            4/4/11
 * Description:     MinMax Data Structure.
 *******************************************************************/

#ifndef MINMAXTREE_H
#define MINMAXTREE_H

#include <iostream>
#include <string>
#include <time.h>
#include <vector>
#include <windows.h>

#include "Data.h"

class MinMaxTree
{
private:
    static bool t_computer_turn;          // who's turn is it?
    static int t_move_number;             // move counter
    static MinMaxTree* t_current;         // current node
    static MinMaxTree* t_root;            // root node
    MinMaxTree* t_parent;                 // parent node
    Data* t_data;                         // data
    std::vector<MinMaxTree*> t_children;  // child nodes

    // Mutators

    /* Pre:         Expects node and max value
     * Post:        Sets node's max value.
     * Purpose:     Used to delete and reset node's max value.
     *******************************************************************/
    void setMax(MinMaxTree* node, int max);

    /* Pre:         Expects node and min value
     * Post:        Sets node's min value.
     * Purpose:     Used to delete and reset node's min value.
     *******************************************************************/
    void setMin(MinMaxTree* node, int min);

    // Insert

    /* Pre:         None.
     * Post:        Inserts max nodes into tree (i.e. computer move nodes).
     * Purpose:     Used to find moves that maximize.
     *******************************************************************/
    void insertMax();

    /* Pre:         None.
     * Post:        Inserts min nodes into tree (i.e. player move nodes).
     * Purpose:     Used to find min nodes that minimize.
     *******************************************************************/
    void insertMin();

    /* Pre:         Expects coordinates passed in to parameter.
     * Post:        Inserts node at location.
     * Purpose:     Used to find moves that maximize.
     *******************************************************************/
    void insertPlayer(int x, int y);

    // Helper Functions

    /* Pre:         Expects parent of child nodes that need cleaning.
     * Post:        Removes all uneeded max child nodes.
     * Purpose:     Used remove uneeded nodes.
     *******************************************************************/
    void cleanUpMax(MinMaxTree* parent);

    /* Pre:         Expects parent of child nodes that need cleaning.
     * Post:        Removes all uneeded min child nodes.
     * Purpose:     Used remove uneeded nodes.
     *******************************************************************/
    void cleanUpMin(MinMaxTree* parent);

    /* Pre:         Expects child and position in table.
     *              (e.g. ((x) 1, (y) 1) = 1)
     * Post:        Creates map based on previous locations and
     *              new location.
     * Purpose:     Used create map of current state.
     *******************************************************************/
    void createMap(MinMaxTree* child, int position);

    /* Pre:         Expects child and coordinates in table.
     * Post:        Creates map based on previous locations and
     *              new location.
     * Purpose:     Used create map of current state.
     *******************************************************************/
    void createMap(MinMaxTree* child, int x, int y);

    /* Pre:         Expects child.
     * Post:        Finds min or max of a given node; depending on
     *              what value you are looking for.
     * Purpose:     Used find min or max value for table.
     *******************************************************************/
    int findMinMax(MinMaxTree* child);

public:
    // Constructors

    /* Pre:         None.
     * Post:        Initializes data.
     * Purpose:     Used initialize data.
     *******************************************************************/
    MinMaxTree();

    /* Pre:         Expects data to be passed into parameter.
     * Post:        Initializes data.
     * Purpose:     Used initialize data.
     *******************************************************************/
    MinMaxTree(Data* data);

    // Destructors

    /* Pre:         None.
     * Post:        Removes data.
     * Purpose:     Used destroy dynamically allocated data.
     *******************************************************************/
    ~MinMaxTree();

    // Delete

    /* Pre:         None (assumes game has reached an end).
     * Post:        Deletes entire tree.
     * Purpose:     Used initialize data.
     *******************************************************************/
    void deleteTree();

    // Accessors

    /* Pre:         Expects coordinates to be passed into parameter.
     * Post:        Return true or false.
     * Purpose:     Used to check wether space in table is clear.
     *******************************************************************/
    bool checkSpace(int x, int y);

    /* Pre:         None.
     * Post:        Returns move numbers.
     * Purpose:     Used return current move number.
     *******************************************************************/
    int getMoveNumber();

    // Insert

    /* Pre:         Expects current player (computer or player) and
     *              coordinates. Coordinates can be set to NULL if
     *              it's the computers turn.
     * Post:        Calls proper insert functions, returns win state.
     * Purpose:     Used call insert functions and return a value
     *              that will determine wether someone is a winner.
     *******************************************************************/
    int insert(bool computer_turn, int x, int y);

    // Display

    /* Pre:         None.
     * Post:        Displays current table to screen.
     * Purpose:     Used display table to screen.
     *******************************************************************/
    void display();
};

#endif
