/* Author:          Chris Brough
 * Date:            4/4/11
 * Description:     MinMax Data Structure.
 *******************************************************************/

#include "minmax.h"

bool MinMaxTree::t_computer_turn = 1;       // current turn
int MinMaxTree::t_move_number = 1;          // move counter
MinMaxTree* MinMaxTree::t_current = NULL;   // current node in tree
MinMaxTree* MinMaxTree::t_root = NULL;      // root node in tree

//
// Constructors
//

MinMaxTree::MinMaxTree()
{
    t_parent = NULL;
    t_data = new Data();
}

MinMaxTree::MinMaxTree(Data* data)
{
    t_parent = NULL;
    t_data = data;
}

//
// Destructors
//

MinMaxTree::~MinMaxTree()
{
    delete t_data;
}

//
// Delete
//

void MinMaxTree::deleteTree()
{
    MinMaxTree *tmp, *next;

    tmp = t_root;
    while (tmp != NULL)
    {
        if (tmp->t_children.size() != 0)
            next = tmp->t_children[0];
        else
            next = NULL;

        delete tmp;

        tmp = next;
    }

    this->t_children.clear();
    delete this;
}

//
// Accessors
//

bool MinMaxTree::checkSpace(int x, int y)
{
    if (t_current->t_data->s_map[x][y] == -1)
        return true;
    else
        return false;
}

int MinMaxTree::getMoveNumber()
{
    return t_move_number;
}

//
// Mutators
//

void MinMaxTree::setMax(MinMaxTree* node, int max)
{
    node->t_data->s_max = max;
}

void MinMaxTree::setMin(MinMaxTree* node, int min)
{
    node->t_data->s_min = min;
}

//
// Insert
//

void MinMaxTree::insertMax()
{
    int i = 0, max = 0;

    if (t_move_number == 1) // inserts root node
    {
        MinMaxTree* node = new MinMaxTree();
        this->t_children.push_back(node);
        this->t_children[0]->t_parent = this;
        createMap(this->t_children[0], 4);
        t_current = this->t_children[0];

        t_root = t_current;
    }
    else                    // inserts set of max nodes
    {
        for (i = 0; i <= (9 - t_move_number); i++)
        {
            MinMaxTree* node = new MinMaxTree();
            t_current->t_children.push_back(node);
            t_current->t_children[i]->t_parent = t_current;
            createMap(t_current->t_children[i], i);

            max = findMinMax(t_current->t_children[i]);

            if (max == -INFINITY)
                max = INFINITY;

            setMax(t_current->t_children[i], max);

            if (max > t_current->t_data->s_max)
                setMax(t_current, max);
        }

        cleanUpMax(t_current); // clean up unecessary max nodes

        if (t_current->t_children.size() > 1)
            insertMin();       // insert min nodes if neccessary
                                    // (i.e. when there are
                                    // two or more equivalent max nodes)

        t_current = t_current->t_children[0]; // reset current node
    }
}

void MinMaxTree::insertMin()
{
    bool game_state = true;
    unsigned int i = 0;
    int k = 0, min = INFINITY;

    switch (t_computer_turn)    // flip turn
    {
    case 1:
        t_computer_turn = 0;
        break;
    case 0:
        t_computer_turn = 1;
        break;
    }

    // insert set of min nodes
    for (i = 0; i < t_current->t_children.size(); i++)
    {
        game_state = true;

        for (k = 0; k <= (9 - t_move_number - 1); k++)
        {
            MinMaxTree* node = new MinMaxTree();
            t_current->t_children[i]->t_children.push_back(node);
            t_current->t_children[i]->t_children[k]->t_parent = t_current->t_children[i];
            createMap(t_current->t_children[i]->t_children[k], k);

            min = findMinMax(t_current->t_children[i]->t_children[k]);
            setMin(t_current->t_children[i]->t_children[k], min);

            if (min < t_current->t_children[i]->t_data->s_min || min == INFINITY)
            {
                if (min == INFINITY)
                {
                    setMin(t_current->t_children[i], min);
                    game_state = false;
                }
                else if (game_state)
                {
                    setMin(t_current->t_children[i], min);
                    setMin(t_current, min);
                }
            }
        }
    }

    cleanUpMin(t_current); // clean up unecessary min nodes
}

void MinMaxTree::insertPlayer(int x, int y)
{
    MinMaxTree* node = new MinMaxTree();
    node->t_parent = t_current;
    t_current = node;
    createMap(node, x, y);
    t_current->t_parent->t_children.push_back(t_current);
}

int MinMaxTree::insert(bool computer_turn, int x, int y)
{
    switch (computer_turn)              // determines insert function
    {
    case true:
        {
            t_computer_turn = 1;
            insertMax();
            break;
        }
    case false:
        {
            t_computer_turn = 0;
            insertPlayer(x, y);
            break;
        }
    }

    t_move_number++;

    return -(findMinMax(t_current));    // returns value
                                            // that can be used
                                            // to determine
                                            // an end game
                                            // scenario.
}

//
// Display
//

void MinMaxTree::display()
{
    int i = 0, k = 0;

    std::cout << " 1 " << " 2 " << " 3 " << "\n" << "\n";

    for (i = 0; i < ROW; i++)
    {
        for (k = 0; k < COL; k++)
        {
            switch (t_current->t_parent->t_children[0]->t_data->s_map[k][i])
            {
            case 1:
                std::cout << " X ";
                break;
            case 0:
                std::cout << " O ";
                break;
            default:
                std::cout << " � ";
                break;
            }
        }
        std::cout << " " << (i + 1) << " " << "\n" << "\n";
    }
}

//
// Helper Functions
//

void MinMaxTree::cleanUpMax(MinMaxTree* parent)
{
    int i = 0;
    MinMaxTree* tmp;

    for (i = parent->t_children.size() - 1; i >= 0; i--)
    {
        if (parent->t_children[i]->t_data->s_max != parent->t_data->s_max)
        {
            tmp = parent->t_children[i];
            parent->t_children[i]->t_parent = NULL;

            delete tmp;
            parent->t_children.erase(parent->t_children.begin() + i);
        }
    }
}

void MinMaxTree::cleanUpMin(MinMaxTree* parent)
{
    int i = 0, k = 0;
    MinMaxTree* tmp;

    // delete all nodes that do not equal the min, including the parent
        // of the min nodes.
    for (i = parent->t_children.size() - 1; i >= 0; i--)
    {
        if (parent->t_data->s_min != parent->t_children[i]->t_data->s_min)
        {
            for (k = parent->t_children[i]->t_children.size() - 1; k >= 0; k--)
            {
                    tmp = parent->t_children[i]->t_children[k];
                    parent->t_children[i]->t_children[k]->t_parent = NULL;
                    delete tmp;
                    parent->t_children[i]->t_children.pop_back();
            }

            delete parent->t_children[i];
            parent->t_children.erase(parent->t_children.begin() + i);
        }
    }

    // delete any duplicate min nodes until there is only one set of min
        // nodes left.
    for (i = parent->t_children.size() - 1; i > 0; i--)
    {
        if (parent->t_data->s_min == parent->t_children[i]->t_data->s_min)
        {
            for (k = parent->t_children[i]->t_children.size() - 1; k >= 0; k--)
            {
                    tmp = parent->t_children[i]->t_children[k];
                    parent->t_children[i]->t_children[k]->t_parent = NULL;
                    delete tmp;
                    parent->t_children[i]->t_children.pop_back();
            }

            delete parent->t_children[i];
            parent->t_children.erase(parent->t_children.begin() + i);
        }
    }

    // delete children of remaining max node.
    if (parent->t_children.size() == 1)
    {
        for (k = parent->t_children[i]->t_children.size() - 1; k >= 0; k--)
        {
            tmp = parent->t_children[0]->t_children[k];
            parent->t_children[0]->t_children[k]->t_parent = NULL;
            delete tmp;
            parent->t_children[0]->t_children.pop_back();
        }
    }
}

void MinMaxTree::createMap(MinMaxTree* child, int position)
{
    int i,
        k,
        count = 0;

    // create map based on previous map and position passed into the
        // parameter
    // the position will be determined by free spaces
        // ex. if position = 5, then the new move will be inserted at
        //      fifth free space
    for (i = 0; i < 3; i++)
    {
        for (k = 0; k < 3; k++)
        {
            if (child->t_parent->t_data->s_map[k][i] == -1)
            {
                if (count == position)
                {
                    child->t_data->s_map[k][i] = t_computer_turn;
                }
                else
                {
                    child->t_data->s_map[k][i] = -1;
                }
                count++;
            }
            else if (child->t_parent->t_data->s_map[k][i] == 1)
            {
                child->t_data->s_map[k][i] = 1;
            }
            else if (child->t_parent->t_data->s_map[k][i] == 0)
            {
                child->t_data->s_map[k][i] = 0;
            }
        }
    }
}

void MinMaxTree::createMap(MinMaxTree* child, int x, int y)
{
    int i, k;

    // create map based on previous map and coordinates passed into the
        // parameter
    for (i = 0; i < 3; i++)
    {
        for (k = 0; k < 3; k++)
        {
            if (child->t_parent->t_data->s_map[k][i] == -1)
            {
                child->t_data->s_map[k][i] = -1;
            }
            else if (child->t_parent->t_data->s_map[k][i] == 1)
            {
                child->t_data->s_map[k][i] = 1;
            }
            else if (child->t_parent->t_data->s_map[k][i] == 0)
            {
                child->t_data->s_map[k][i] = t_computer_turn;
            }
        }
    }

    // add new move after copying map to child node.
    child->t_data->s_map[x][y] = 0;
}

int MinMaxTree::findMinMax(MinMaxTree* child)
{
    bool computer = true,
         player = true;

    int i,
        k,
        count_computer = 0,
        count_player = 0,
        min_max_computer = 0,
        min_max_player = 0,
        min_max = -INFINITY;


    // check horzinotal potential moves
    for (i = 0; i < 3; i++)
    {
        count_computer = 0;
        count_player = 0;

        for (k = 0; k < 3; k++)
        {
            switch (child->t_data->s_map[k][i])
            {
                case _COMPUTER:
                {
                    if (computer != false)
                        computer = true;
                    player = false;
                    count_computer++;
                    break;
                }
                case _PLAYER:
                {
                    if (player != false)
                        player = true;
                    computer = false;
                    count_player++;
                    break;
                }
            }
        }

        if (count_computer == 3)    // win/lose scenarios
            return -INFINITY;
        else if (count_player == 3)
            return INFINITY;
        //else if (count_player == 2 && count_computer == 1)
            //return 10;

        if (computer == true)
            min_max_computer++;

        if (player == true)
            min_max_player++;

        computer = true;
        player = true;
    }


    // check vertical potential moves
    for (i = 0; i < 3; i++)
    {
        count_computer = 0;
        count_player = 0;

        for (k = 0; k < 3; k++)
        {
            switch (child->t_data->s_map[i][k])
            {
                case _COMPUTER:
                {
                    if (computer != false)
                        computer = true;
                    player = false;
                    count_computer++;
                    break;
                }
                case _PLAYER:
                {
                    if (player != false)
                        player = true;
                    computer = false;
                    count_player++;
                    break;
                }
            }
        }

        if (count_computer == 3)
            return -INFINITY;
        else if (count_player == 3)
            return INFINITY;
        //else if (count_player == 2 && count_computer == 1)
            //return 10;

        if (computer == true)
            min_max_computer++;

        if (player == true)
            min_max_player++;

        computer = true;
        player = true;
    }


    // check diagonal potential moves
    for (i = 0; i < 3;)
    {
        count_computer = 0;
        count_player = 0;

        for (k = 0; k < 3; k++)
        {
            switch (child->t_data->s_map[k][i])
            {
                case _COMPUTER:
                {
                    if (computer != false)
                        computer = true;
                    player = false;
                    count_computer++;
                    break;
                }
                case _PLAYER:
                {
                    if (player != false)
                        player = true;
                    computer = false;
                    count_player++;
                    break;
                }
            }
            i++;
        }

        if (count_computer == 3)
            return -INFINITY;
        else if (count_player == 3)
            return INFINITY;
        //else if (count_player == 2 && count_computer == 1)
            //return 10;

        if (computer == true)
            min_max_computer++;

        if (player == true)
            min_max_player++;

        computer = true;
        player = true;
    }


    // check diagonal potential moves (opposite direction)
    for (i = 0; i < 3;)
    {
        count_computer = 0;
        count_player = 0;

        for (k = 2; k >= 0; k--)
        {
            switch (child->t_data->s_map[k][i])
            {
                case _COMPUTER:
                {
                    if (computer != false)
                        computer = true;
                    player = false;
                    count_computer++;
                    break;
                }
                case _PLAYER:
                {
                    if (player != false)
                        player = true;
                    computer = false;
                    count_player++;
                    break;
                }
            }
            i++;
        }

        if (count_computer == 3)
            return -INFINITY;
        else if (count_player == 3)
            return INFINITY;
        //else if (count_player == 2 && count_computer == 1)
            //return 10;

        if (computer == true)
            min_max_computer++;

        if (player == true)
            min_max_player++;

        computer = true;
        player = true;
    }

    // determine min and max out of move possibilites found
    if (t_computer_turn)
    {
        min_max = (min_max_computer - min_max_player);
    }
    else if (!t_computer_turn)
    {
        min_max = (min_max_player - min_max_computer);
    }

    return min_max;
}
