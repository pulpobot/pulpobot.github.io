/* Author:          Chris Brough
 * Date:            4/4/11
 * Description:     Main; includes game setup
 *******************************************************************/

#include "minmax.h"

bool checkWinLose(MinMaxTree* tree, int win_lose);
void clear();

int main()
{
    bool game_over = false;                     // end game
    bool bad_value = false;                     // bad input value

    int win_lose = 0;                           // determine who won
                                                    //(i.e. player/computer)
    int x, y;                                   // input coordinates

    std::string x_string, y_string;             // input coordinates

    MinMaxTree *tree = new MinMaxTree();        // tree

    tree->insert(true, NULL, NULL);             // insert computer move
    tree->display();                            // display game

    while (!game_over)
    {
        do                                      // input validation
        {
            std::cout << "--------------" << "\n";
            do
            {
                std::cout << " x - coord: ";
                std::cin >> x_string;
                x = atoi(x_string.c_str());
            } while (x != 1 && x != 2 && x != 3);

            do
            {
                std::cout << " y - coord: ";
                std::cin >> y_string;
                y = atoi(y_string.c_str());
            } while (y != 1 && y != 2 && y != 3);

            if (tree->checkSpace((x - 1), (y - 1)))
                bad_value = false;
            else
            {
                bad_value = true;
                std::cout << "--------------" << "\n";
                std::cout << "Bad Coordinate" << "\n";
            }

        } while (bad_value);

        clear();

        win_lose = tree->insert(false, (x - 1), (y - 1));   // insert player move
        game_over = checkWinLose(tree, win_lose);           // check for game over

        clear();                                            // clear screen

        if (win_lose != INFINITY && win_lose != -INFINITY)  // insert computer move
        {
            win_lose = tree->insert(true, NULL, NULL);
            game_over = checkWinLose(tree, win_lose);
        }
        else
        {
            win_lose = tree->insert(true, NULL, NULL);
        }
        tree->display();                                    // display tree

        if (game_over)
        {
            std::cout << "Press Enter to Quit...";
            std::cin.get();
            std::cin.get();
        }
    }

    tree->deleteTree();                                     // delete tree

    return 0;
}

bool checkWinLose(MinMaxTree* tree, int win_lose)
{
    if (win_lose == INFINITY)
    {
        std::cout << "--------------" << "\n";
        std::cout << "Computer Won"   << "\n";
        std::cout << "--------------" << "\n";

        return true;
    }
    else if (win_lose == -INFINITY)
    {
        std::cout << "--------------" << "\n";
        std::cout << "Player Won"     << "\n";
        std::cout << "--------------" << "\n";

        return true;
    }
    else if (tree->getMoveNumber() == 10)
    {
        std::cout << "--------------" << "\n";
        std::cout << "No More Moves"  << "\n";
        std::cout << "--------------" << "\n";

        return true;
    }

    return false;
}

void clear()
{
    system("cls");
}
