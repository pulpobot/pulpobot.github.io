//--------------------------------------------------------------------------------//
/// @files bezier_curve.h
/// @author Chris Brough http://www.chrisbrough.com chris@chrisbrough.com
/// @date 2013
//--------------------------------------------------------------------------------//

#ifndef BEZIER_CURVE_H
#define BEZIER_CURVE_H

#include <math_types.h>
#include <graphics_types.h>
#include <types.h>
#include <view_types.h>

#include <vector>

namespace curve {

namespace bezier_flags {

    enum Enum
    {
        SHOW_POINTS = 1 << 0,
        SHOW_CONTROLS = 1 << 1,
        SHOW_CURVE = 1 << 2
    };

} // namespace bezier flags

class BezierCurve
{
public:
    BezierCurve();
    BezierCurve(std::vector<math::Vector3>& control_vertices,
        std::vector<float>& parameters, math::Vector2& range, int degree,
        float resolution);
    ~BezierCurve();

    /// @brief generates draw vertices from control points and calls bind
    void init(void);

    /// @brief updates bezier curve (currently unused)
    void update(const float delta_time);

    /// @brief draw bezier curve and debug data according to the set flags
    void draw(const graphics::ShaderProgram& program, const view::Camera& camera) const;

    inline void add_control_vertice(math::Vector3& vertice) { control_vertices.push_back(vertice); }
    inline void add_parameter(float parameter) { parameters.push_back(parameter); }

    inline void clear_control_vertices() { control_vertices.clear(); }
    inline void clear_parameters() { parameters.clear(); }

    inline void set_range(const math::Vector2& range) { this->range = range; }
    inline void set_degree(const int degree) { this->degree = degree; }
    inline void set_resolution(const float resolution) { this->resolution = resolution; }

    inline void toggle_flag(const int flag) { this->flags = this->flags ^ flag; }

private:
    /// @brief binds vertex data to OpenGL vertex handles
    void bind(void);

    /// @brief calculates additional vertices according to resolution * degree
    void calculate_resolution_vertices(const int control_index, const int param_index);

    /// @brief calculates vertices on curve using constant parametric bezier with control points
    math::Vector3 calculate_bezier(const float param, const int start_index) const;

    uint32_t control_vertex_buffer_handle;
    uint32_t draw_vertex_buffer_handle;

    std::vector<math::Vector3> control_vertices;
    std::vector<math::Vector3> draw_vertices;
    std::vector<float> parameters;
    math::Vector2 range;
    int degree;
    float resolution;
    uint32_t flags;
};

} // namespace curve

#endif
