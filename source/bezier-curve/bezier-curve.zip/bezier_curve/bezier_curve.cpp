//--------------------------------------------------------------------------------//
/// @files bezier_curve.cpp
/// @author Chris Brough http://www.chrisbrough.com chris@chrisbrough.com
/// @date 2013
//--------------------------------------------------------------------------------//

#include "bezier_curve.h"

#include <color.h>
#include <matrix.h>
#include <shader.h>
#include <vector.h>

#include <math.h>

#include <gl/glew.h>

using namespace graphics;
using namespace math;
using namespace std;

namespace curve {

BezierCurve::BezierCurve() :
    range(vector2::zero),
    degree(0.0f),
    resolution(0.0f),
    flags(bezier_flags::SHOW_CURVE)
{

}

BezierCurve::BezierCurve(vector<Vector3>& control_vertices,
    vector<float>& parameters, Vector2& range, int degree, float resolution) :
        control_vertices(control_vertices),
        parameters(parameters),
        range(range),
        degree(degree),
        resolution(resolution),
        flags(bezier_flags::SHOW_CURVE)
{

}

BezierCurve::~BezierCurve()
{

}

void BezierCurve::init(void)
{
    draw_vertices.clear();

    for (int i = 0; i < control_vertices.size(); i += degree)
    {
        // ensure there are enough remaining control points
        if ((i + degree) < control_vertices.size())
        {
            for (int j = 0; j < parameters.size(); ++j)
            {
                draw_vertices.push_back(calculate_bezier(parameters[j], i));

                // comment to remove additional resolution vertices
                calculate_resolution_vertices(i, j);
            }
        }
    }

    bind();
}

void BezierCurve::update(const float delta_time)
{

}

void BezierCurve::draw(const ShaderProgram& program, const view::Camera& camera) const
{
    const Matrix4x4 transform = matrix4x4::identity;
    const Matrix4x4 mvp = camera.frustum.projection * camera.transform * transform;

    glLineWidth(2.0f);
    glPointSize(6.0f);

    glUniformMatrix4fv(program.uniform_mvp_handle, 1, GL_FALSE, mvp.m);
    glEnableVertexAttribArray(shader_attrib_type::VERTEX);

    if (flags & bezier_flags::SHOW_CONTROLS)
    {
        glUniform4fv(program.uniform_color_handle, 1, (GLfloat*)&color::red);
        glBindBuffer(GL_ARRAY_BUFFER, control_vertex_buffer_handle);
        glVertexAttribPointer(shader_attrib_type::VERTEX, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
        glDrawArrays(GL_LINE_STRIP, 0, control_vertices.size());

        if (flags & bezier_flags::SHOW_POINTS)
        {
            glDrawArrays(GL_POINTS, 0, control_vertices.size());
        }
    }

    if (flags & bezier_flags::SHOW_CURVE)
    {
        glUniform4fv(program.uniform_color_handle, 1, (GLfloat*)&color::green);
        glBindBuffer(GL_ARRAY_BUFFER, draw_vertex_buffer_handle);
        glVertexAttribPointer(shader_attrib_type::VERTEX, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
        glDrawArrays(GL_LINE_STRIP, 0, draw_vertices.size());

        if (flags & bezier_flags::SHOW_POINTS)
        {
            glDrawArrays(GL_POINTS, 0, draw_vertices.size());
        }
    }

    glDisableVertexAttribArray(shader_attrib_type::VERTEX);
    glLineWidth(1.0f);
}

void BezierCurve::bind(void)
{
    glGenBuffers(1, &control_vertex_buffer_handle);
    glBindBuffer(GL_ARRAY_BUFFER, control_vertex_buffer_handle);
    glBufferData(GL_ARRAY_BUFFER, control_vertices.size() * sizeof(math::Vector3),
        &control_vertices[0], GL_STATIC_DRAW);

    glGenBuffers(1, &draw_vertex_buffer_handle);
    glBindBuffer(GL_ARRAY_BUFFER, draw_vertex_buffer_handle);
    glBufferData(GL_ARRAY_BUFFER, draw_vertices.size() * sizeof(math::Vector3),
        &draw_vertices[0], GL_STATIC_DRAW);
}

void BezierCurve::calculate_resolution_vertices(const int control_index, const int param_index)
{
    if (resolution > 0 && param_index < (parameters.size() - 1))
    {
        const int subdivision_count = resolution * degree;
        const float distance = (parameters[param_index + 1] - parameters[param_index]);
        const float subdivision_length = distance/subdivision_count;

        float previous = parameters[param_index];

        for (int i = 0; i < subdivision_count - 1; ++i)
        {
            previous += subdivision_length;
            draw_vertices.push_back(calculate_bezier(previous, control_index));
        }
    }
}

Vector3 BezierCurve::calculate_bezier(const float param, const int start_index) const
{
    int i, j;
    float* u = (float*)malloc(degree * sizeof(float));
    float* t = (float*)malloc(degree * sizeof(float));
    Vector3 p = vector3::zero;

    // range
    u[0] = (range.y - param)/(range.y - range.x);
    t[0] = (param - range.x)/(range.y - range.x);

    // calculate powers for degrees
    for (i = 1; i < degree; ++i)
    {
        u[i] = powf(u[0], i + 1);
        t[i] = powf(t[0], i + 1);
    }

    // first term
    p += control_vertices[start_index] * u[degree - 1];

    // calculate inner terms for any degree
    //     increments t and decrements u
    for (i = 1, j = degree - 2; i < degree; ++i, --j)
    {
        p += control_vertices[start_index + i] * degree * u[j] * t[i - 1];
    }

    // last term
    p += control_vertices[start_index + degree] * t[degree - 1];

    free(u);
    free(t);

    return p;
}

} // namespace curve
