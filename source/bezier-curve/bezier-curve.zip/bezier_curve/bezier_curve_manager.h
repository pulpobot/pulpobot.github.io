//--------------------------------------------------------------------------------//
/// @files bezier_curve_manager.h
/// @author Chris Brough http://www.chrisbrough.com chris@chrisbrough.com
/// @date 2013
//--------------------------------------------------------------------------------//

#ifndef BEZIER_CURVE_MANAGER_H
#define BEZIER_CURVE_MANAGER_H

#include "bezier_curve.h"

#include <graphics_types.h>
#include <math_types.h>
#include <view_types.h>

#include <vector>

namespace curve {

class BezierCurveManager
{
public:
    BezierCurveManager();
    ~BezierCurveManager();

    /// @brief loads bezier curves from ".obj" files
    bool load(const char* filename);

    /// @brief calls init on managed bezier curves
    void init(void);

    /// @brief calls update on managed bezier curves
    void update(const float deltat_time);

    /// @brief calls draw on active bezier curve (change active with "cycle_active_curve")
    void draw(const graphics::ShaderProgram& program, const view::Camera& camera) const;

    /// @brief generate bezier curve of the fibonacci/goldan spiral
    void generate_fibonacci_spiral(const int count);

    /// @brief update the last and current with the next fibonacci number
    void fibonacci_number(int& last, int& current);

    void cycle_active_curve();
    void toggle_flag(const int flag);

private:
    std::vector<BezierCurve> bezier_curves;
    int active_bezier_curve;
};

} // namespace curve

#endif
