//--------------------------------------------------------------------------------//
/// @files bezier_curve_manager.cpp
/// @author Chris Brough http://www.chrisbrough.com chris@chrisbrough.com
/// @date 2013
//--------------------------------------------------------------------------------//

#include "bezier_curve_manager.h"

#include <shader.h>
#include <vector.h>

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

using namespace graphics;
using namespace math;
using namespace std;

namespace curve {

BezierCurveManager::BezierCurveManager() :
    active_bezier_curve(0)
{

}

BezierCurveManager::~BezierCurveManager()
{

}

bool BezierCurveManager::load(const char* filename)
{
    BezierCurve curve;
    vector<math::Vector3> vertices;
    Vector2 range = vector2::zero;
    int degree = 0;
    float resolution = 0.0f;
    bool open_curve = false;

    string line;
    ifstream ifs(filename, ifstream::in);

    if (ifs.fail())
    {
        cerr << "error: failed to open \"" << filename << "\"\n";
    }

    while(ifs.good() && !ifs.eof() && getline(ifs, line))
    {
        string key = "";
        stringstream stream(line);
        stream >> key >> ws;

        if (key == "v")
        {
            Vector3 vertice = vector3::zero;
            stream >> vertice.x >> ws >> vertice.y >> ws >> vertice.z;
            vertices.push_back(vertice);
        }
        else if (key == "cstype")
        {
            stream >> key >> ws;

            if (key != "bezier")
            {
                cerr << "error: non-bezier curve\n";
                ifs.close();
                return false;
            }
        }
        else if (key == "ctech")
        {
            stream >> key >> ws;

            if (key != "cparm")
            {
                cerr << "error: non-cparm curve\n";
                ifs.close();
                return false;
            }

            stream >> resolution >> ws;
        }
        else if (key == "deg")
        {
            stream >> degree >> ws;

            if (degree < 1)
            {
                cerr << "error: invalid degree\n";
                ifs.close();
                return false;
            }
        }
        else if (key == "curv")
        {
            open_curve = true;
            curve = BezierCurve();

            stream >> range.x >> ws >> range.y;

            curve.set_range(range);
            curve.set_degree(degree);
            curve.set_resolution(resolution);

            int indice = 0;

            while (!stream.eof())
            {
                stream >> indice;

                if (--indice >= 0 && indice < vertices.size())
                {
                    curve.add_control_vertice(vertices[indice]);
                }
            }
        }
        else if (key == "parm")
        {
            curve.clear_parameters();

            stream >> key >> ws;

            if (key != "u")
            {
                cerr << "error: invalid parameter coordinate type\n";
                ifs.close();
                return false;
            }

            float parameter = 0.0f;

            while (!stream.eof())
            {
                stream >> parameter;
                curve.add_parameter(parameter);
            }
        }
        else if (key == "end")
        {
            open_curve = false;
            bezier_curves.push_back(curve);
            curve = BezierCurve();
        }
        else if (key == "g")
        {
            // handle groups here
        }
        else if (key.size() > 0 && key[0] > 35)
        {
            cerr << "error: \"" << key << "\" is invalid for bezier curves\n";
            ifs.close();
            return false;
        }
    }

    ifs.close();

    return true;
}

void BezierCurveManager::init(void)
{
    for (int i = 0; i < bezier_curves.size(); ++i)
    {
        bezier_curves[i].init();
    }
}

void BezierCurveManager::update(const float delta_time)
{
    for (int i = 0; i < bezier_curves.size(); ++i)
    {
        bezier_curves[i].update(delta_time);
    }
}

void BezierCurveManager::draw(const ShaderProgram& program, const view::Camera& camera) const
{
    shader::begin_program(program);

    if (active_bezier_curve < bezier_curves.size())
    {
        bezier_curves[active_bezier_curve].draw(program, camera);
    }

    // uncomment to render all bezier curves
    //for (int i = 0; i < bezier_curves.size(); ++i)
    //{
        //bezier_curves[i].draw(program, camera);
    //}

    shader::end_program();
}

void BezierCurveManager::cycle_active_curve()
{
    if (++active_bezier_curve >= bezier_curves.size())
    {
        active_bezier_curve = 0;
    }
}

void BezierCurveManager::toggle_flag(const int flag)
{
    for (int i = 0; i < bezier_curves.size(); ++i)
    {
        bezier_curves[i].toggle_flag(flag);
    }
}

void BezierCurveManager::generate_fibonacci_spiral(const int count)
{
    int i = 0;
    int last = 0;
    int current = 1;

    BezierCurve fibonacci_spiral;

    Vector2 range = Vector2(0.0f, 1.0f);

    fibonacci_spiral.set_range(range);
    fibonacci_spiral.set_degree(4);
    fibonacci_spiral.set_resolution(2.0f);

    for (i = 0; i < 9; ++i)
    {
        fibonacci_spiral.add_parameter(i * 0.125f);
    }

    Vector3 origin = vector3::zero;
    Vector3 up = Vector3(0.0f, 1.0f, 0.0f);

    fibonacci_spiral.add_control_vertice(origin);
    fibonacci_spiral.add_control_vertice(up);

    Vector3 previous = up;

    Vector3 east1 = vector3::zero;
    Vector3 east2 = vector3::zero;

    Vector3 south1 = vector3::zero;
    Vector3 south2 = vector3::zero;

    Vector3 west1 = vector3::zero;
    Vector3 west2 = vector3::zero;

    Vector3 north1 = vector3::zero;
    Vector3 north2 = up;

    for (i = 0; i < count; ++i)
    {
        // east

        east1 = north2 + Vector3(current, 0.0f, 0.0f);
        east2 = east1 + Vector3(current + last, 0.0f, 0.0f);

        fibonacci_spiral.add_control_vertice(east1);
        fibonacci_spiral.add_control_vertice(east2);

        // south

        fibonacci_number(last, current);

        south1 = east2 + Vector3(0.0f, -current, 0.0f);
        south2 = south1 + Vector3(0.0f, -current - last, 0.0f);

        fibonacci_spiral.add_control_vertice(south1);
        fibonacci_spiral.add_control_vertice(south2);

        // west

        fibonacci_number(last, current);

        west1 = south2 + Vector3(-current, 0.0f, 0.0f);
        west2 = west1 + Vector3(-current - last, 0.0f, 0.0f);

        fibonacci_spiral.add_control_vertice(west1);
        fibonacci_spiral.add_control_vertice(west2);

        // north

        fibonacci_number(last, current);

        north1 = west2 + Vector3(0.0f, current, 0.0f);
        north2 = north1 + Vector3(0.0f, current + last, 0.0f);

        fibonacci_spiral.add_control_vertice(north1);

        if (i < count - 1)
        {
            fibonacci_spiral.add_control_vertice(north2);
        }
    }

    bezier_curves.push_back(fibonacci_spiral);
}

void BezierCurveManager::fibonacci_number(int& last, int& current)
{
    const int tmp = last;
    last = current;
    current = tmp + current;
}

} // namespace curve
