#ifndef STACK_ALLOCATOR_H
#define STACK_ALLOCATOR_H

#include "memory.h"

#include <stdlib.h>
#include <stdint.h>

namespace memory {

namespace allocator {

class StackAllocator
{
public:
    StackAllocator(void* start, size_t size);

    void* allocate(size_t size, uint32_t alignment = DEFAULT_ALIGN);
    void deallocate(void* ptr);
    void rewind(void);

private:
    uint8_t* start;
    uint8_t* end;
    uint8_t* offset;
    uint32_t count;
};

} // namespace allocator

} // namespace memory

#endif
