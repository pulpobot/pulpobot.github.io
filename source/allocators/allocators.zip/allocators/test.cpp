#include "linear_allocator.h"
#include "pool_allocator.h"
#include "scope_stack_allocator.h"
#include "stack_allocator.h"

#include <assert.h>
#include <stdio.h>

using namespace memory;
using namespace allocator;

struct Foo
{
    int a;
    int b;
};

struct Bar
{
    int data[4];
};

class FooBar
{
public:
    FooBar()
    {
        printf("In FooBar Constructor\n");
    }

    ~FooBar()
    {
        printf("In FooBar Destructor\n");
    }

private:
    int a;
    int b;
};

void test_linear_allocator(void);
void test_stack_allocator(void);
void test_scope_stack_allocator(void);
void test_pool_allocator(void);

int main(int argc, char** argv)
{
    test_linear_allocator();
    test_stack_allocator();
    test_scope_stack_allocator();
    test_pool_allocator();

    return 0;
}

void test_linear_allocator(void)
{
    printf("--- Linear Allocater ---\n");

    const size_t test_size = 16;
    char* test_data = (char*)malloc(sizeof(char) * test_size);

    LinearAllocator a = LinearAllocator(test_data, test_size);

    Foo* f1 = (Foo*)a.allocate(sizeof(Foo), 8);
    Foo* f2 = (Foo*)a.allocate(sizeof(Foo), 8);
    Foo* f3 = (Foo*)a.allocate(sizeof(Foo), 4);

    f1->a = 100;
    f1->b = 20;

    assert(f1 != NULL);
    assert(f2 != NULL);
    assert(f3 == NULL);

    f1 = f2 = f3 = NULL;

    a.rewind();

    Foo* f4 = (Foo*)a.allocate(sizeof(Bar), 4);
    Foo* f5 = (Foo*)a.allocate(sizeof(Bar), 4);

    assert(f4 != NULL);
    assert(f5 == NULL);

    f4 = f5 = NULL;

    free(test_data);
}

void test_stack_allocator(void)
{
    printf("--- Stack Allocater ---\n");

    const size_t test_size = 64;
    char test_data[test_size];

    StackAllocator a = StackAllocator(&test_data, test_size);

    Foo* f1 = (Foo*)a.allocate(sizeof(Foo), 4);
    Foo* f2 = (Foo*)a.allocate(sizeof(Foo), 4);

    assert(f1 != NULL);
    assert(f2 != NULL);

    a.deallocate(f2);

    f2 = NULL;

    Foo* f3 = (Foo*)a.allocate(sizeof(Foo), 4);

    assert(f3 != NULL);

    a.rewind();

    f1 = f2 = f3 = NULL;

    Foo* f4 = (Foo*)a.allocate(sizeof(Foo), 32);
    Foo* f5 = (Foo*)a.allocate(sizeof(Foo), 16);
    Foo* f6 = (Foo*)a.allocate(sizeof(Foo));

    assert(f4 != NULL);
    assert(f5 != NULL);
    assert(f6 != NULL);
}

void test_scope_stack_allocator(void)
{
    printf("--- Scope Stack Allocater ---\n");

    const size_t test_size = 128;
    char test_data[test_size];

    LinearAllocator a = LinearAllocator(&test_data, test_size);
    ScopeStackAllocator scope_a = ScopeStackAllocator(a);

    FooBar* f1 = scope_a.allocate_object<FooBar>();
    FooBar* f2 = scope_a.allocate_object<FooBar>();

    assert(f1 != NULL);
    assert(f2 != NULL);

    {
        ScopeStackAllocator scope_b = ScopeStackAllocator(a);

        FooBar* f3 = scope_b.allocate_object<FooBar>();
        FooBar* f4 = scope_b.allocate_object<FooBar>();
        Foo* f5 = scope_b.allocate_pod<Foo>();
    }
}

void test_pool_allocator(void)
{
    printf("--- Pool Allocater ---\n");

    const size_t test_size = 32;
    char* test_data = (char*)malloc(sizeof(char) * test_size);

    PoolAllocator a = PoolAllocator(test_data, test_size, 8);

    Foo* f1 = (Foo*)a.allocate();
    Foo* f2 = (Foo*)a.allocate();
    Foo* f3 = (Foo*)a.allocate();
    Foo* f4 = (Foo*)a.allocate();
    Foo* f5 = (Foo*)a.allocate();

    assert(f1 != NULL);
    assert(f2 != NULL);
    assert(f3 != NULL);
    assert(f4 != NULL);
    assert(f5 == NULL);

    a.deallocate(f2);

    f2 = NULL;

    f5 = (Foo*)a.allocate();

    assert(f5 != NULL);

    Foo* f6 = (Foo*)a.allocate();

    assert(f6 == NULL);

    free(test_data);
}
