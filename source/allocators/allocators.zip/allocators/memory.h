#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>
#include <stdlib.h>

namespace memory {

static const size_t DEFAULT_ALIGN = 4;
static const size_t ALLOCATION_OFFSET = sizeof(uint32_t);
static const size_t COUNT_OFFSET = sizeof(uint32_t);

size_t align(const size_t size, const uint32_t alignment);

inline size_t align(size_t size, uint32_t alignment)
{
    return (size + (alignment - 1)) & ~(alignment - 1);
}

} // namespace memory

#endif
