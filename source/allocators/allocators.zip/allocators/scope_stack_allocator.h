#ifndef SCOPE_STACK_ALLOCATOR_H
#define SCOPE_STACK_ALLOCATOR_H

#include "linear_allocator.h"

#include <new>

namespace memory {

namespace allocator {

struct Finalizer
{
    void (*fn)(void* ptr);
    Finalizer* next;
};

template <typename T>
void destructor(void* ptr)
{
    ((T*)(ptr))->~T();
}

class ScopeStackAllocator
{
public:
    ScopeStackAllocator(LinearAllocator& linear_allocator,
        uint32_t alignment = DEFAULT_ALIGN);
    ~ScopeStackAllocator();

    template<typename T>
    T* allocate_object()
    {
        Finalizer* finalizer = (Finalizer*)linear_allocator.allocate(
            align(sizeof(Finalizer), alignment));

        finalizer->fn = &destructor<T>;
        finalizer->next = finalizer_chain;
        finalizer_chain = finalizer;

        return new (linear_allocator.allocate(align(sizeof(T), alignment))) T;
    }

    template<typename T>
    T* allocate_pod()
    {
        return new (linear_allocator.allocate(sizeof(T), alignment)) T;
    }

private:
    LinearAllocator& linear_allocator;
    void* linear_allocator_offset;
    Finalizer* finalizer_chain;
    uint32_t alignment;
};

} // namespace allocator

} // namespace memory

#endif
