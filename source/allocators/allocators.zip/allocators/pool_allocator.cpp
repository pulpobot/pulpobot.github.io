#include "pool_allocator.h"

#include <assert.h>

namespace memory {

namespace allocator {

PoolAllocator::PoolAllocator(void* start, size_t size, size_t chunk_size,
    uint32_t alignment) :
        start((uint8_t*)start)
{
    assert(start);
    assert(size);
    assert(chunk_size);
    assert(chunk_size >= sizeof(uint8_t*));

    chunk_size = align(chunk_size, alignment);

    union
    {
        void* start_void;
        uint8_t* start_uint8;
    };

    start_void = start;

    const uint32_t chunk_count = (size/chunk_size) - 1;

    for (uint32_t i = 0; i < chunk_count; ++i)
    {
        uint8_t* current_chunk = start_uint8 + (i * chunk_size);
        *(uint8_t**)current_chunk = current_chunk + chunk_size;
    }

    *((uint8_t**)&start_uint8[chunk_count * chunk_size]) = NULL;
    next = start_uint8;
}

void* PoolAllocator::allocate(void)
{
    if (!next)
    {
        return NULL;
    }

    uint8_t* current = next;
    next = *((uint8_t**)next);

    return current;
}

void PoolAllocator::deallocate(void* ptr)
{
    if (!ptr)
    {
        return;
    }

    *((uint8_t**)ptr) = next;
    next = (uint8_t*)ptr;
}

} // namespace allocator

} // namespace memory
