#include "linear_allocator.h"

#include <assert.h>

namespace memory {

namespace allocator {

LinearAllocator::LinearAllocator(void* start, size_t size) :
    start((uint8_t*)start),
    end((uint8_t*)start + size),
    offset((uint8_t*)start)
{
    assert(start != NULL);
    assert(size > 0);
}

void* LinearAllocator::allocate(size_t size, uint32_t alignment)
{
    size = align(size, alignment);

    if ((offset + size) <= end)
    {
        uint8_t* old_offset = offset;
        offset = offset + size;
        return old_offset;
    }

    return NULL;
}

void* LinearAllocator::get_offset(void) const
{
    return offset;
}

void LinearAllocator::rewind(void)
{
    offset = start;
}

void LinearAllocator::rewind(void* ptr)
{
    offset = (uint8_t*)ptr;
}

} // namespace allocator

} // namespace memory
