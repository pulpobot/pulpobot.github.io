#include "stack_allocator.h"

#include <assert.h>

namespace memory {

namespace allocator {

StackAllocator::StackAllocator(void* start, size_t size) :
    start((uint8_t*)start),
    end((uint8_t*)start + size),
    offset((uint8_t*)start),
    count(0)
{
    assert(start != NULL);
    assert(size > 0);
}

void* StackAllocator::allocate(size_t size, uint32_t alignment)
{
    size += ALLOCATION_OFFSET + COUNT_OFFSET;
    size = align(size, alignment);

    if ((offset + size) <= end)
    {
        const uint32_t allocation_offset = (uint32_t)(offset - start);

        union
        {
            void* void_ptr;
            char* char_ptr;
            uint32_t* uint32_ptr;
        };

        void_ptr = offset;

        *uint32_ptr = allocation_offset;
        char_ptr += ALLOCATION_OFFSET;

        *uint32_ptr = ++count;
        char_ptr += COUNT_OFFSET;

        void* previous_offset = (uint8_t*)void_ptr;
        offset += size;
        return previous_offset;
    }

    return NULL;
}

void StackAllocator::deallocate(void* ptr)
{
    assert(ptr != NULL);

    union
    {
        void* void_ptr;
        char* char_ptr;
        uint32_t* uint32_ptr;
    };

    void_ptr = ptr;

    char_ptr -= COUNT_OFFSET;
    assert(count == *uint32_ptr);

    char_ptr -= ALLOCATION_OFFSET;
    const uint32_t allocation_offset = *uint32_ptr;

    offset = start + allocation_offset;
}

void StackAllocator::rewind(void)
{
    offset = start;
}

} // namespace allocator

} // namespace memory
