#include "scope_stack_allocator.h"

namespace memory {

namespace allocator {

ScopeStackAllocator::ScopeStackAllocator(LinearAllocator& linear_allocator,
    uint32_t alignment) :
        linear_allocator(linear_allocator),
        linear_allocator_offset(linear_allocator.get_offset()),
        alignment(alignment),
        finalizer_chain(NULL)
{

}

ScopeStackAllocator::~ScopeStackAllocator()
{
    for (Finalizer* f = finalizer_chain; f; f = f->next)
    {
        (*f->fn)((uint8_t*)f + align(sizeof(Finalizer), alignment));
    }

    linear_allocator.rewind(linear_allocator_offset);
}

} // namespace allocator

} // namespace memory
