#ifndef LINEAR_ALLOCATOR_H
#define LINEAR_ALLOCATOR_H

#include "memory.h"

#include <stdlib.h>
#include <stdint.h>

namespace memory {

namespace allocator {

class LinearAllocator
{
public:
    LinearAllocator(void* start, size_t size);

    void* get_offset(void) const;

    void* allocate(size_t size, uint32_t alignment = DEFAULT_ALIGN);
    void rewind(void);
    void rewind(void* ptr);

private:
    uint8_t* start;
    uint8_t* end;
    uint8_t* offset;
};

} // namespace allocator

} // namespace memory

#endif
