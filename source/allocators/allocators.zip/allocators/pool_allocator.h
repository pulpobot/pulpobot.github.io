#ifndef POOL_ALLOCATOR_H
#define POOL_ALLOCATOR_H

#include "memory.h"

#include <stdlib.h>
#include <stdint.h>

namespace memory {

namespace allocator {

class PoolAllocator
{
public:
    PoolAllocator(void* start, size_t size, size_t chunk_size,
        uint32_t alignment = DEFAULT_ALIGN);

    void* allocate(void);
    void deallocate(void* ptr);

private:
    uint8_t* next;
    uint8_t* start;
};

} // namespace allocator

} // namespace memory

#endif
